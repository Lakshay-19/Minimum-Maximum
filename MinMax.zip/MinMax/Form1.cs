﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


//Lakshay Punj
//May 6, 2019
//MinMax program

namespace MinMax
{
    public partial class Form1 : Form
    {
        //global variables 
        int[] Integers;


        public Form1()
        {
            InitializeComponent();
        }

        private void mnuFileLoad_Click(object sender, EventArgs e)
        {
            //load file into array

            //Open file dialogue

            OpenFileDialog fd = new OpenFileDialog();

            if (fd.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(fd.OpenFile());
                int Records = int.Parse(sr.ReadLine());
                Integers = new int[Records];

                for (int i=0; i < Records; i++)
                {
                    Integers[i] = int.Parse(sr.ReadLine());
                }
                lblOutput.Text = "File loaded";

            }

            else
            {
                lblOutput.Text = "File did not load";
            }

        }

        private void mnuFileMax_Click(object sender, EventArgs e)
        {
            //output max value of array and location

            int MaxNum = Integers[0];

            
            for (int index = 0; index < Integers.Length; index++)
            {
                if (Integers[index] > MaxNum)
                {
                    MaxNum = Integers[index];
              
                }
            
            }
            lblOutput.Text = "The Max value is " + MaxNum +  "\n" + "The location is ";

        }

        private void mnuFileMin_Click(object sender, EventArgs e)
        {
            //output min value of array and location

            int MinNum = Integers[0];

            for (int index = 0; index < Integers.Length; index++)
            {
                if (Integers[index] < MinNum)
                {
                    MinNum = Integers[index];

                }

            }
            lblOutput.Text = "The Min value is " + MinNum + "\n" + "The location is ";



        }


    }
}
